(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6b60d2b0._.js",
  "static/chunks/src_app_login_page_jsx_180e15c3._.js"
],
    source: "dynamic"
});
